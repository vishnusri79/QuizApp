//
//  QuizBankEditDelegate.swift
//  QuizBank
//
//  Created by  user NY551 on 3/31/24.
//

import Foundation

protocol QuizBankEditDelegate : AnyObject {
    func didEditQuestion(_ question: Question, originalQuestion: Question)
}
