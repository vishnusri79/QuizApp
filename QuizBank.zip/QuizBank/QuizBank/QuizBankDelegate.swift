//
//  QuizBankDelegate.swift
//  QuizBank
//
//  Created by  user NY551 on 3/30/24.
//

import Foundation

protocol QuizBankDelegate : AnyObject {
    func getQuestions() -> [Question]
}
