//
//  ResultsViewController.swift
//  QuizBank
//
//  Created by user NY551 on 3/31/24.
//

import UIKit

class ResultsViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        resultLabel.text = "Average result = \(result)"

        // Do any additional setup after loading the view.
    }
    
    var result: Float = 0.0
    
    @IBOutlet weak var resultLabel: UILabel!
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
