//
//  QuestionAddViewController.swift
//  QuizBank
//
//  Created by  user NY551 on 3/30/24.
//

import UIKit

class QuestionAddViewController: UIViewController {
    
    weak var delegate: QuizBankAddDelegate?
    
    func addquestion(_ question: Question) {
        if let delegate {
            delegate.didAddQuestion(question)
        } else {
            print("No Delegate Assigned")
        }
    }
    
    @IBAction func dismissTheView(_ sender: UIBarButtonItem) {
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBOutlet weak var questionFromTheTextFeild: UITextField!
    
    
    @IBOutlet weak var correctAnswerFromTheTextField: UITextField!
    

    @IBOutlet weak var wrongAnswer1: UITextField!
    
    @IBOutlet weak var wrongAnswer2: UITextField!
    
    @IBOutlet weak var wrongAnswer3: UITextField!
    
    
    @IBAction func saveTheQuestion(_ sender: UIBarButtonItem) {
        if let questiontext = questionFromTheTextFeild.text, let correctAnswer = correctAnswerFromTheTextField.text, let wrongAnswer1 = wrongAnswer1.text, let wrongAnswer2 = wrongAnswer2.text, let wrongAnswer3 = wrongAnswer3.text {
            let question = Question(questionText: questiontext, correctAnswer: correctAnswer, allAnswers: [correctAnswer, wrongAnswer1, wrongAnswer2, wrongAnswer3])
            
            addquestion(question)
            self.dismiss(animated: true, completion: nil)
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
