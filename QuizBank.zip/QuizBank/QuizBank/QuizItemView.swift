//
//  QuizItemView.swift
//  QuizBank
//
//  Created by  user NY551 on 3/31/24.
//

import UIKit

class QuizItemView: UITableViewCell {

    @IBOutlet weak var question: UILabel!
    
    @IBOutlet weak var correctAnswer: UILabel!
    
    @IBOutlet var wrongAnswers: [UILabel]!
}
