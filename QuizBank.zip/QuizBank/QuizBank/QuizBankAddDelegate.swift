//
//  QuizBankAddDelegate.swift
//  QuizBank
//
//  Created by  user NY551 on 3/30/24.
//

import Foundation

protocol QuizBankAddDelegate : AnyObject {
    func didAddQuestion(_ question: Question)
}
