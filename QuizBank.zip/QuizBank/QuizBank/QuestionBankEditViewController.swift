//
//  QuestionBankEditViewController.swift
//  QuizBank
//
//  Created by  user NY551 on 3/31/24.
//

import UIKit

class QuestionBankEditViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        loadTheView()
    }
    
    var selectedQuestion : Question?
    
    
    func loadTheView() {
        
        if let question = selectedQuestion {
            print(question)
            questionTextField.text = question.questionText
            correctAnswerTextField.text = question.correctAnswer
            
            
            let incorrectAnswers = question.allAnswers.filter { $0 != question.correctAnswer }
            
            wrongAnswer1Field.text = incorrectAnswers[0]
            wrongAnswer2Field.text = incorrectAnswers[1]
            wrongAnswer3Field.text = incorrectAnswers[2]
        }
        
        
    }
        
    weak var delegate : QuizBankEditDelegate?
    
    @IBOutlet weak var questionTextField: UITextField!
    
    @IBOutlet weak var correctAnswerTextField: UITextField!
    
    
    @IBOutlet weak var wrongAnswer1Field: UITextField!
    
    
    @IBOutlet weak var wrongAnswer2Field: UITextField!
    
    @IBOutlet weak var wrongAnswer3Field: UITextField!
    
    
    @IBAction func cancelTheEdit(_ sender: UIBarButtonItem) {
        self.dismiss(animated: true, completion: nil)
    }
    
    
    @IBAction func saveTheEdit(_ sender: UIBarButtonItem) {
        if let questiontext = questionTextField.text, let correctAnswer = correctAnswerTextField.text, let wrongAnswer1 = wrongAnswer1Field.text, let wrongAnswer2 = wrongAnswer2Field.text, let wrongAnswer3 = wrongAnswer3Field.text {
            let question = Question(questionText: questiontext, correctAnswer: correctAnswer, allAnswers: [correctAnswer, wrongAnswer1, wrongAnswer2, wrongAnswer3])
            
            editTheQuestion(question)
            self.dismiss(animated: true, completion: nil)
        }
    }
    
    
    func editTheQuestion(_ question: Question) {
        if let delegate, let selectedQuestion {
            delegate.didEditQuestion(question, originalQuestion: selectedQuestion)
        } else {
            print("No Delegate Assigned")
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
