//
//  Question.swift
//  QuizBank
//
//  Created by  user NY551 on 3/30/24.
//

import Foundation

struct Question : Equatable {
    var questionText: String
    var correctAnswer: String
    var allAnswers: [String]
}

