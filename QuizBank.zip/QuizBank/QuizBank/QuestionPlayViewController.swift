//
//  QuestionPlayViewController.swift
//  QuizBank
//
//  Created by user NY551 on 3/30/24.
//

import UIKit

class QuestionPlayViewController: UIViewController {
    
    weak var delegate: QuizBankDelegate?
    
    lazy var questions: [Question] = delegate?.getQuestions() ?? []

    var currentQuestionIndex = 0
    
    var savedAnswers : [String: String] = [:]
    
    @IBOutlet weak var questionLabel: UILabel!
    
    @IBOutlet var answerOptions: [UIButton]!
    
    
    @IBAction func selectAnAnswer(_ sender: Any) {
        if let button = sender as? UIButton, let buttonIndex = answerOptions.firstIndex(of: button) {
            savedAnswers[questions[currentQuestionIndex].questionText] = questions[currentQuestionIndex].allAnswers[buttonIndex]
            answerOptions.forEach { $0.setImage(UIImage(systemName: "circle.circle"), for: .normal) }
            button.setImage(UIImage(systemName: "circle.circle.fill"), for: .normal)
            
        }
    }
    
    @IBAction func goToPreviousQuestion(_ sender: UIButton) {
        if currentQuestionIndex > 0 {
            currentQuestionIndex -= 1
        }
        setUpQuestionLabels()
    }
    
    @IBAction func goToNextQuestion(_ sender: UIButton) {
        if currentQuestionIndex < questions.count {
            currentQuestionIndex += 1
        }
        setUpQuestionLabels()
    }
    
    func setUpQuestionLabels() {
        if questions.indices.contains(currentQuestionIndex) {
            let currentQuestion = questions[currentQuestionIndex]
            questionLabel.text = currentQuestion.questionText
            answerOptions.forEach {
                $0.setImage(UIImage(systemName: "circle.circle"), for: .normal)
            }
            for labelIndex in 0..<answerOptions.count {
                answerOptions[labelIndex].setTitle(currentQuestion.allAnswers[labelIndex], for: .normal)
                if currentQuestion.allAnswers[labelIndex] == savedAnswers[currentQuestion.questionText] {
                    answerOptions[labelIndex].setImage(UIImage(systemName: "circle.circle.fill"), for: .normal)
                }
            }
            progressOfTheGame.progress = Float(currentQuestionIndex + 1) / Float(questions.count)
        }
        
    }
    
    @IBOutlet weak var progressOfTheGame: UIProgressView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpQuestionLabels()

        // Do any additional setup after loading the view.
    }


    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        print("preparing")
        var result : Float = 0.0
        for question in questions {
            if savedAnswers[question.questionText] == question.correctAnswer {
                result += 1
            }
            
        }
        if let destinationVC = segue.destination as? ResultsViewController {
            if questions.count != 0 {
                destinationVC.result = result / Float(questions.count)
            }
        }
    }

}
