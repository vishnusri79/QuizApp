//
//  QuizBankViewController.swift
//  QuizBank
//
//  Created by  user NY551 on 3/30/24.
//

import UIKit

class QuizBankViewController: UIViewController, QuizBankAddDelegate, QuizBankDelegate, QuizBankEditDelegate {
    
    func didAddQuestion(_ question: Question) {
        questions.append(question)
        print(questions)
    }
    func didEditQuestion(_ question: Question, originalQuestion: Question) {
        if let index = questions.firstIndex(of: originalQuestion) {
            questions[index] = question
        }
    }
    var questions: [Question] = []
    
    func getQuestions() -> [Question] {
        return questions
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        print(segue.destination.title ?? "Issue")
        if let destinationVC = segue.destination as? QuizBankListViewController {
            destinationVC.questionBankdelegate = self
            destinationVC.delegate = self
            destinationVC.quizBankEditDelegate = self
        }
        if let destinationVC = segue.destination as? QuestionPlayViewController {
            destinationVC.delegate = self
        }
    }
    
    
}

